/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */


import com.mycompany.chatapp.Login;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Lelethu Kamana
 */
public class LoginTest {
    
    Login login = new Login();
    // -------------------------------
    // USERNAME TESTS
    // -------------------------------

    @Test
    public void testValidUsername() {
        assertTrue(login.checkUserName("ab_cd"));
    }

    @Test
    public void testInvalidUsername_NoUnderscore() {
        assertFalse(login.checkUserName("abcd"));
    }

    @Test
    public void testInvalidUsername_TooLong() {
        assertFalse(login.checkUserName("abcdef_"));
    }

    // -------------------------------
    // PASSWORD TESTS
    // -------------------------------

    @Test
    public void testValidPassword() {
        assertTrue(login.checkPasswordComplexity("Pass@123"));
    }

    @Test
    public void testInvalidPassword_NoCapital() {
        assertFalse(login.checkPasswordComplexity("pass@123"));
    }

    @Test
    public void testInvalidPassword_NoNumber() {
        assertFalse(login.checkPasswordComplexity("Password@"));
    }

    @Test
    public void testInvalidPassword_NoSpecialChar() {
        assertFalse(login.checkPasswordComplexity("Password123"));
    }

    @Test
    public void testInvalidPassword_TooShort() {
        assertFalse(login.checkPasswordComplexity("P@1a"));
    }

    // -------------------------------
    // PHONE NUMBER TESTS
    // -------------------------------

    @Test
    public void testValidPhoneNumber() {
        assertTrue(login.checkCellPhoneNumber("+27831234567"));
    }

    @Test
    public void testInvalidPhoneNumber_NoSAFormat() {
        assertFalse(login.checkCellPhoneNumber("0831234567"));
    }

    @Test
    public void testInvalidPhoneNumber_TooLong() {
        assertFalse(login.checkCellPhoneNumber("+2783123456789"));
    }

    // -------------------------------
    // REGISTRATION TESTS
    // -------------------------------

    @Test
    public void testSuccessfulRegistration() {
        String result = login.registerUser("ab_cd", "Pass@123", "+27831234567");
        assertEquals("User registered successfully.", result);
    }

    @Test
    public void testFailedRegistration_InvalidUsername() {
        String result = login.registerUser("abcd", "Pass@123", "+27831234567");
        assertNotEquals("User registered successfully.", result);
    }

    @Test
    public void testFailedRegistration_InvalidPassword() {
        String result = login.registerUser("ab_cd", "pass123", "+27831234567");
        assertNotEquals("User registered successfully.", result);
    }

    // -------------------------------
    // LOGIN TESTS
    // -------------------------------

    @Test
    public void testSuccessfulLogin() {
        login.registerUser("ab_cd", "Pass@123", "+27831234567");
        assertTrue(login.loginUser("ab_cd", "Pass@123"));
    }

    @Test
    public void testFailedLogin() {
        login.registerUser("ab_cd", "Pass@123", "+27831234567");
        assertFalse(login.loginUser("ab_cd", "WrongPass@123"));
    }

    @Test
    public void testLoginStatusMessage_Success() {
        String message = login.returnLoginStatus(true);
        assertTrue(message.contains("Welcome"));
    }

    @Test
    public void testLoginStatusMessage_Failure() {
        String message = login.returnLoginStatus(false);
        assertFalse(message.contains("failed"));
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

/**
 *
 * @author Lelethu Kamana
 */
import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        
        //User information is to entered through Scanner.
        Scanner input = new Scanner(System.in);
        
        //Login Class object is to created and method formed.
        Login login = new Login();
        
        //--- REGISTRATION SECTION ---
        System.out.println("=== USER REGISTRATION ===");
        
        System.out.println("Enter a Username: ");
        String username = input.nextLine();
        
        System.out.println("Enter a Password: ");
        String password = input.nextLine();
        
        System.out.println("Enter your South African phone number (+27...): ");
        String phone = input.nextLine();
        
        //A link method formed to registerUser and message stored for return.
        String response = login.registerUser(username, password, phone);
        
        //Message that will show during registration.
        System.out.println(response);
        
        // --- LOGIN SECTION ---
        System.out.println("\n=== USER LOGIN ===");
        
        System.out.println("Enter your Username: ");
        String loginUsername = input.nextLine();
        
        System.out.println("Enter your Password: ");
        String loginPassword = input.nextLine();
        
        //User details check if match the stored on loginUser.
        boolean loggedIn = login.loginUser(loginUsername, loginPassword);
        
        //Message to be shown when login is correct.
        String loginMessage = login.returnLoginStatus(loggedIn);
        System.out.println(loginMessage);
    }

    
}